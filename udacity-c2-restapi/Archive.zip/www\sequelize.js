"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sequelize = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
// import { config } from './config/config';
require("dotenv/config");
require('dotenv').config();
// const c = config.dev;
console.log(process.env.pass_word);
// Instantiate new Sequelize instance!
exports.sequelize = new sequelize_typescript_1.Sequelize({
    "username": process.env.user_name,
    "password": process.env.pass_word,
    "database": process.env.database,
    "host": process.env.host,
    dialect: 'postgres',
    storage: ':memory:',
});
//# sourceMappingURL=sequelize.js.map